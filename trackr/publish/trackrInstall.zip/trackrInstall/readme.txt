To install trackr, simply run the setup.exe executable.

This will install trackr in AppData. It can then be uninstalled via the control panel's programs menu.